//paul schmid
// 9/11/2014/
// Expressions**

 var firstN=prompt ("What is your first name?");
console.log(firstN);

var lastN=prompt ("What is your last name?");
console.log(lastN);

var first=firstN;
var last=lastN;
fullName=first + " " +last;
console.log(fullName);

alert(" I would like to know how many cds and dvds that you have?");

var dvds=prompt ("how many dvds do you have?");
console.log(dvds);
var cds=prompt ("how many dvds do you have?");
console.log(cds);

alert(" Off the info given you have "+dvds+" dvds and "+cds+" cds!");

var dvdTypes=["horror", "action", "comedy", "romance"];
